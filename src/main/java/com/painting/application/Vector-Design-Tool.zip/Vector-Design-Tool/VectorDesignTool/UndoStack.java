import java.util.Stack;

public class UndoStack extends UndoCommand {

    private int undoRedoPointer = -1;
    private Stack<Command> commandStack = new Stack<>();

    public UndoStack(DrawingVecPanel drawingVecPanel) {
        super( drawingVecPanel );
    }

    public void undoCommand(){
        deleteElementsAfterPointer(undoRedoPointer);
        Command command = new UndoCommand(drawingVecPanel);
        command.execute();
        commandStack.push(command);
        undoRedoPointer++;
    }

    private void deleteElementsAfterPointer(int undoRedoPointer) {
        if (commandStack.size()<1)return;
        for (int i = commandStack.size()-1; i > undoRedoPointer;i--){
            commandStack.remove( i );
        }
    }
    private void undo()
    {
        Command command = commandStack.get(undoRedoPointer);
        command.unExecute();
        undoRedoPointer--;
    }

    private void redo()
    {
        if(undoRedoPointer == commandStack.size() - 1)
            return;
     undoRedoPointer++;
        Command command = commandStack.get(undoRedoPointer);
        command.execute();
    }
}