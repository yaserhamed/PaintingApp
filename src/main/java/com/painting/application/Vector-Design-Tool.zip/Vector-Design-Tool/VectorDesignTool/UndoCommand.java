import java.awt.image.BufferedImage;
import java.util.Stack;

public class UndoCommand extends Command
{

    DrawingVecPanel drawingVecPanel;
    Memento memento;

    public UndoCommand(DrawingVecPanel drawingVecPanel) {
        this.drawingVecPanel = drawingVecPanel;
    }

    @Override
    void execute() {
     memento = new Memento();
     memento.setDrawingVecPanel(drawingVecPanel);
    }

    @Override
    void unExecute() {
      this.drawingVecPanel = memento.getDrawingVecPanel();
    }

}
