/**
 *   VECTOR DESIGN TOOL
 *
 */

import javax.swing.*;
import java.awt.*;

public class VectorDesign extends JFrame
{
    /**************************************************************************************************************
     *****************************************************VARIABLES************************************************
     **************************************************************************************************************/
    public DrawingVecPanel drawingPanel;
    protected MenuBar menuBar;
    protected ColorPalette colorPalette;
    public VectorToolPanel vectorToolPanel;
    public UndoStack undoStack;



    /**************************************************************************************************************
     ***************************************************CONSTRUCTOR************************************************
     **************************************************************************************************************/
    public VectorDesign(){
        super("VectorDesignTool");  //overriding JFrame's title

        ImageIcon ImageIcon = getIcon("/images/IMG_BOJA_48.png");
        assert ImageIcon != null;
        Image Image = ImageIcon.getImage();


        drawingPanel = new DrawingVecPanel();                              //create drawing panel
        menuBar = new MenuBar();                                        //create menu bar
        colorPalette = new ColorPalette();                              //create color palette panel
        vectorToolPanel = new VectorToolPanel(new StrokeToolPanel(5));   //create drawing tool panel
        add(menuBar, "North");                                 //add panels to the main JFrame
        add(colorPalette, "South");
        add(vectorToolPanel, "West");
        add(new JScrollPane(drawingPanel), "Center");

        this.setIconImage(Image);    //setting JFrame's icon image
        this.setSize(1024, 768);     //set size of the application
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);   //set default close operation
        this.setLocationRelativeTo(null);                               //set locating to the middle of the screen
        this.setVisible(true);                                          //set visible
        setStaringColor();                                             //set the starting color
    }

    /**************************************************************************************************************
     ***************************************************METHODS****************************************************
     **************************************************************************************************************/
    public void setStaringColor()     //set starting color to be used for drawing
    {
        ColorPalette.selectedColorDisplay.setBackground(Color.black);
        ColorPalette.selectedColor = ColorPalette.selectedColorDisplay.getBackground();
        drawingPanel.currentToolDetails.setColor(ColorPalette.selectedColorDisplay.getBackground());
        drawingPanel.brushColor = ColorPalette.selectedColor;
    }

    /**
     * Method used to return the ImageIcon object that has the path
     * equal to the one given to the method as an input parameter.
     * In case the inputted imagePath parameter is not valid
     * an exception will be caught in the try catch block
     * and the default image used in the JOptionPane
     * @param imagePath  class path
     * @return ImageIcon
     */
    public static ImageIcon getIcon(String imagePath)
    {
        try
        {
            return new ImageIcon(VectorDesign.class.getResource(imagePath));
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Invalid image path");
            return null;
        }
    }

}
