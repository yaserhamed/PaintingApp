public abstract class Command {
    DrawingVecPanel drawingVecPanel;
    Memento memento;

    abstract void execute();
    abstract void unExecute();

}
