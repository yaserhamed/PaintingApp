public class Memento
{
    DrawingVecPanel drawingVecPanel;

    public DrawingVecPanel getDrawingVecPanel() {
        return drawingVecPanel;
    }

    public void setDrawingVecPanel(DrawingVecPanel drawingVecPanel) {
        this.drawingVecPanel = drawingVecPanel;
    }
}
