/**
 *   VECTOR DESIGN TOOL
 */

//class used to create different tool instances, depending on the given type parameter
public class Tool
{
    public int toolType;
    public Tool (int type)
    {
       toolType = type;
    }
}
