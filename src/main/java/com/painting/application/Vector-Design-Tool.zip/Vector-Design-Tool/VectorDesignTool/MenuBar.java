/**
 *   VECTOR DESIGN TOOL
 */



import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;



//Class used to display the application's menu bar
public class MenuBar extends JMenuBar
{
    /**************************************************************************************************************
     *****************************************************VARIABLES************************************************
     **************************************************************************************************************/
    public JMenu file, edit, zoom;
    public JMenuItem quit, newFile, openFile, saveFile, vec, undo,zoomin,zoomout;
    public JFileChooser fileChooser = null;
    private double scale = 1;
    private double prevScale = 1;
    private boolean zoomer;

    /**************************************************************************************************************
     *****************************************************CONSTRUCTOR***********************************************
     **************************************************************************************************************/
    public MenuBar()
    {

        MenuOptionsHandler itemHandler = new MenuOptionsHandler();   //create the Menu ActionListener
        file = new JMenu("File");                                    //create the menu tabs and options
        edit = new JMenu( "Edit" );
        zoom = new JMenu( "Zoom" );

        newFile = new JMenuItem("New File");
        openFile = new JMenuItem("Open File");
        saveFile = new JMenuItem("Save File");
        quit = new JMenuItem("Exit");
        vec = new JMenuItem( "Save As VEC" );
        undo = new JMenuItem( "Undo" );
        zoomin = new JMenuItem( "Zoom-In" );
        zoomout = new JMenuItem( "Zoom-out" );
        newFile.addActionListener(itemHandler);                      //add actionListeners
        openFile.addActionListener(itemHandler);
        saveFile.addActionListener(itemHandler);
        quit.addActionListener(itemHandler);
        vec.addActionListener(itemHandler);
        undo.addActionListener(itemHandler);
        zoomin.addActionListener(itemHandler);
        zoomout.addActionListener(itemHandler);
        file.add(newFile);                                           //add options to the menu
        file.add(openFile);
        file.add(saveFile);
        file.addSeparator();
        file.add(quit);
        file.add(vec);
        edit.add(undo);
        zoom.add(zoomin);
        zoom.add(zoomout);
        add(file);
        add(edit);
        add(zoom);

    }

    /**************************************************************************************************************
     *****************************************************FILE METHODS*********************************************
     **************************************************************************************************************/

    public JFileChooser getFileChooser()
    {
        if (fileChooser ==null)
        {
            fileChooser = new JFileChooser();                        //create file chooser
            fileChooser.setFileFilter(new PNGFileFilter());         //set file extension to .png
            fileChooser.setFileFilter( new BMPFileFilter());       //set file extension to .bmp
        }
        return fileChooser;
    }

    public static BufferedImage getScreenShot(Component component)    //used to get the current image drawn on the screen
    {
        BufferedImage image = new BufferedImage(component.getWidth(), component.getHeight(), BufferedImage.TYPE_INT_RGB);
        component.paint(image.getGraphics());   // paints into image's Graphics
        return image;
    }


    /**************************************************************************************************************
     **************************************************ACTION EVENTS************************************************
     **************************************************************************************************************/
    private class MenuOptionsHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if (event.getSource() == quit)          //if Exit application
            {
                Main.vector.dispose();
                System.exit(0);
            }
            if (event.getSource() == newFile)       //if New File
            {

                BufferedImage bi = new BufferedImage(1024, 768, BufferedImage.TYPE_INT_ARGB);   //create new BufferedImage
                Main.vector.drawingPanel.clearImage(bi);                                         //clear current image
                Main.vector.drawingPanel.setImage(bi);                                           //set image to new blank image
            }
            if (event.getSource() == saveFile)      //if Save file
            {
                JFileChooser jFileChooser = getFileChooser();                                            //open file chooser
                int result = jFileChooser.showSaveDialog(Main.vector.drawingPanel);
                if (result==JFileChooser.APPROVE_OPTION )
                {
                    try
                    {
                        File selectedFile = jFileChooser.getSelectedFile();
                        File selectedFile1 = jFileChooser.getSelectedFile();
                        selectedFile = new File(selectedFile.getAbsolutePath() + ".png");      //get isSelected file
                        selectedFile1 = new File(selectedFile1.getAbsolutePath() + ".bmp");      //get isSelected file
                        BufferedImage img = getScreenShot(Main.vector.drawingPanel);            //get current image screenshot
                        ImageIO.write(img, "png", selectedFile);                     //write the image to the isSelected file
                        ImageIO.write(img, "bmp", selectedFile1);                     //write the image to the isSelected file
                    } catch (IOException ioe)
                    {
                        JOptionPane.showMessageDialog(null, "Could not save the file");
                    }
                }
            }
            if (event.getSource() == openFile)       //if Open file
            {
                JFileChooser ch = getFileChooser();                                            //open file chooser
                int result = ch.showOpenDialog(Main.vector.drawingPanel);
                if (result==JFileChooser.APPROVE_OPTION )                                      //if OK
                {
                    try
                    {
                        Main.vector.drawingPanel.setOSImage(ImageIO.read(ch.getSelectedFile())); //set current image to isSelected image
                    } catch (IOException ex)
                    {
                        JOptionPane.showMessageDialog(null, "Could not open file");
                    }
                }
            }
            if (event.getSource() == zoomin)
            {
                Main.vector.drawingPanel.IncreaseSize();
            }
            if (event.getSource() == zoomout)
            {
                Main.vector.drawingPanel.DecreaseSize();
            }
            if (event.getSource() == undo){

                Main.vector.undoStack.execute();
            }
        }
    }

    /**************************************************************************************************************
     **************************************************FILE EXTENSION CLASS****************************************
     **************************************************************************************************************/
    private static class PNGFileFilter extends FileFilter
    {
        public boolean accept(File file)             //filer files to display
        {
            return file.getName().toLowerCase().endsWith(".png") || file.isDirectory();
        }

        public String getDescription()
        {
            return "PNG image  (*.png) ";
        }
    }

    private static class BMPFileFilter extends FileFilter
    {
        public boolean accept(File file)        //filer files to display
        {
            return file.getName().toLowerCase().endsWith(".bmp") || file.isDirectory();
        }
        public String getDescription() { return "Bitmap image (*.bmp) "; }
    }


}