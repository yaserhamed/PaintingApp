/**
 *   VECTOR DESIGN TOOL
 */

//Class which serves for creating the appropriate tool class
public class ToolFactory
{
    /**************************************************************************************************************
     *****************************************************VARIABLES************************************************
     **************************************************************************************************************/
    private static Tool brushTool;                    //variables to hold different tool class instances
    private static Tool pencilTool;
    private static Tool eraserTool;
    private static Tool ellipseTool;
    private static Tool lineTool;
    private static Tool rectangleTool;
    private static Tool fillerTool;
    private static Tool polygonTool;
    private static Tool filledRectangleTool;
    private static Tool filledEllipseTool;
    private static Tool filledPolygonTool;
    private static Tool airBrushTool;
    private static Tool plotTool;
    private static Tool currentTool;


    public static final int BRUSH_TOOL = 0;             //static constant variables used to differentiate the tool classes
    public static final int PENCIL_TOOL = 1;
    public static final int ERASER_TOOL= 2;
    public static final int FILLER_TOOL= 3;
    public static final int POLYGON_TOOL = 4;
    public static final int ELLIPSE_TOOL= 5;
    public static final int RECTANGLE_TOOL = 6;
    public static final int LINE_TOOL= 7;
    public static final int AIR_BRUSH_TOOL= 8;
    public static final int FILLED_RECTANGLE_TOOL= 9;
    public static final int FILLED_ELLIPSE_TOOL= 10;
    public static final int FILLED_POLYGON_TOOL= 11;
    public static final int PLOT_TOOL = 12;


    /**************************************************************************************************************
     *************************************************FACTORY METHOD***********************************************
     **************************************************************************************************************/
    /**
     * Creates a new instance of the Tool (depending on the given parameter), passing in the tool type parameter
     * Sets the  currentTool view to that of the newly created class
     * @param toolTYpe  String parameter defining the type of the tool that is to be created
     * @return   currentTool
     */
    public static Tool createTool(int toolTYpe)
    {
        switch (toolTYpe) {
            case 0:
                if (brushTool == null)                //if class is null
                    brushTool = new Tool( BRUSH_TOOL );             //create new class instance
                currentTool = brushTool;                       //set currentTool to that class instance
                break;
            case 1:
                if (pencilTool == null)
                    pencilTool = new Tool( PENCIL_TOOL );
                currentTool = pencilTool;
                break;
            case 2:
                if (eraserTool == null)
                    eraserTool = new Tool( ERASER_TOOL );
                currentTool = eraserTool;
                break;
            case 3:
                if (fillerTool == null)
                    fillerTool = new Tool( FILLER_TOOL );
                currentTool = fillerTool;
                break;
            case 4:
                if (polygonTool == null)
                    polygonTool = new Tool(POLYGON_TOOL);
                currentTool = polygonTool;
                break;
            case 5:
                if (ellipseTool == null)
                    ellipseTool = new Tool( ELLIPSE_TOOL );
                currentTool = ellipseTool;
                break;
            case 6:
                if (rectangleTool == null)
                    rectangleTool = new Tool( RECTANGLE_TOOL );
                currentTool = rectangleTool;
                break;
            case 7:
                if (lineTool == null)
                    lineTool = new Tool( LINE_TOOL );
                currentTool = lineTool;
                break;
            case 8:
                if (airBrushTool == null)
                    airBrushTool = new Tool( AIR_BRUSH_TOOL );
                currentTool = airBrushTool;
                break;
            case 9:
                if (filledRectangleTool == null)
                    filledRectangleTool = new Tool( FILLED_RECTANGLE_TOOL );
                currentTool = filledRectangleTool;
                break;
            case 10:
                if (filledEllipseTool == null)
                    filledEllipseTool = new Tool( FILLED_ELLIPSE_TOOL );
                currentTool = filledEllipseTool;
                break;
            case 11:
                if (filledPolygonTool == null)
                    filledPolygonTool = new Tool( FILLED_POLYGON_TOOL );
                currentTool = filledPolygonTool;
                break;
            case 12:
                if (plotTool == null)
                    plotTool = new Tool( PLOT_TOOL );
                currentTool = plotTool;
        }
        return currentTool;
    }
}
