/**
 *   VECTOR DESIGN TOOL
 */

public class Main
{
    public static VectorDesign vector;

    /**
     * Application starting point, creates a new instance of the VectorApplication class
     * @param args String arguments
     */
    public static void main(String args[]) throws Exception {
        vector = new VectorDesign();
    }


}
